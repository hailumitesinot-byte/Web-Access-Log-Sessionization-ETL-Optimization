import sys

from etl.sessionize import run


def main() -> None:
    if len(sys.argv) != 3:
        print("usage: python -m etl <input.jsonl> <output.jsonl>", file=sys.stderr)
        raise SystemExit(2)
    input_path, output_path = sys.argv[1], sys.argv[2]
    run(input_path, output_path)


if __name__ == "__main__":
    main()
