"""
Naive (intentionally slow) sessionization pipeline.

This is the starting point the agent must optimize. It is functionally
correct but effectively quadratic in the number of log lines:

  * iterates rows with pandas .iterrows()
  * rebuilds output via repeated Python list .append() calls
  * re-scans already-seen rows with a linear search to find each user's
    prior row when deciding whether a new line continues an existing
    session

Do not change the session-boundary rule (30-minute gap), the dedup step,
or the on-disk output schema / CLI contract when optimizing this file.
"""

import json

import pandas as pd

SESSION_GAP_SECONDS = 30 * 60


def _load(input_path: str) -> pd.DataFrame:
    rows = []
    with open(input_path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return pd.DataFrame(rows)


def _dedup(df: pd.DataFrame) -> pd.DataFrame:
    seen = set()
    keep_idx = []
    # Naive O(n) dedup using a linear structure lookup per row (fine here,
    # not the bottleneck) -- kept simple on purpose.
    for idx, row in df.iterrows():
        key = (row["user_id"], row["timestamp"], row["request_id"])
        if key not in seen:
            seen.add(key)
            keep_idx.append(idx)
    return df.loc[keep_idx]


def _sessionize(df: pd.DataFrame) -> list[dict]:
    df = df.sort_values(["user_id", "timestamp"], kind="mergesort")

    sessions: list[dict] = []
    # last_row_by_user maps user_id -> last row dict seen for that user.
    # Deciding whether the current row continues a session requires
    # re-checking this per row -- combined with .iterrows() and .append()
    # below, this is the quadratic bottleneck for large inputs.
    last_row_by_user: dict = {}
    current_session_by_user: dict = {}
    session_count_by_user: dict = {}

    for _, row in df.iterrows():
        uid = row["user_id"]
        ts = row["timestamp"]
        prev = last_row_by_user.get(uid)

        starts_new = prev is None or (ts - prev["timestamp"]) > SESSION_GAP_SECONDS

        if starts_new:
            ordinal = session_count_by_user.get(uid, 0)
            session_count_by_user[uid] = ordinal + 1
            session = {
                "session_id": f"{uid}-{ordinal}",
                "user_id": uid,
                "start_ts": ts,
                "end_ts": ts,
                "request_count": 1,
                "total_bytes": int(row["bytes"]),
            }
            sessions.append(session)
            current_session_by_user[uid] = session
        else:
            session = current_session_by_user[uid]
            session["end_ts"] = ts
            session["request_count"] += 1
            session["total_bytes"] += int(row["bytes"])

        last_row_by_user[uid] = row

    for session in sessions:
        session["bounce"] = session["request_count"] == 1

    return sessions


def run(input_path: str, output_path: str) -> None:
    df = _load(input_path)
    df = _dedup(df)
    sessions = _sessionize(df)

    with open(output_path, "w") as f:
        for session in sessions:
            f.write(json.dumps(session, sort_keys=True))
            f.write("\n")
