#!/usr/bin/env bash
# Applies the reference optimized implementation over the starter
# etl/sessionize.py and demonstrates the task is solvable within budget.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

cp "${REPO_ROOT}/solution/sessionize.py" "${REPO_ROOT}/etl/sessionize.py"

echo "Reference solution installed at etl/sessionize.py"
echo "Run: python -m etl <input.jsonl> <output.jsonl>"
