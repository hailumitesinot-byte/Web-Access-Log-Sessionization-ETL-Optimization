"""
Reference optimized sessionization pipeline.

Replaces row-wise iteration + repeated linear scans with a vectorized
pandas pipeline:

  1. Load and dedupe on (user_id, timestamp, request_id).
  2. Sort by (user_id, timestamp) -- stable sort, handles approximately
     (not globally) ordered input and timestamp ties deterministically.
  3. Compute per-user time deltas via a grouped .diff().
  4. Flag new-session boundaries where the delta exceeds 1800s (30 min)
     or is null (first row per user). Ties at exactly 1800s do NOT start
     a new session (delta must strictly exceed the gap).
  5. Assign session ids via a cumulative sum of boundary flags.
  6. Aggregate with a single groupby(...).agg(...).

This is O(n log n), dominated by the sort, with no Python-level
per-row loop and no repeated re-scanning of prior rows.
"""

import json

import pandas as pd
import pyarrow.json as paj

SESSION_GAP_SECONDS = 30 * 60


def _load(input_path: str) -> pd.DataFrame:
    # A pure-Python per-line json.loads loop is the actual bottleneck on
    # multi-million-line input (dominates wall-clock and peak memory far
    # more than the vectorized groupby logic below). Use pyarrow's native
    # JSON reader instead -- it's already baked into the image -- which is
    # roughly an order of magnitude faster and lower-memory. It infers
    # "timestamp" as int64 (no datetime coercion), matching the schema.
    table = paj.read_json(input_path)
    return table.to_pandas()


def run(input_path: str, output_path: str) -> None:
    df = _load(input_path)

    # Dedup before sessionization.
    df = df.drop_duplicates(subset=["user_id", "timestamp", "request_id"])

    # Stable sort so approximately-ordered input and same-timestamp ties
    # are handled deterministically and consistently with the naive
    # reference (mergesort is stable).
    df = df.sort_values(["user_id", "timestamp"], kind="mergesort").reset_index(
        drop=True
    )

    # Per-user gap to previous row; NaN on each user's first row.
    delta = df.groupby("user_id")["timestamp"].diff()

    # New session starts where there's no previous row for this user,
    # or the gap strictly exceeds the 30-minute threshold.
    new_session = delta.isna() | (delta > SESSION_GAP_SECONDS)

    # Global running session id, then a per-user session_id string that
    # matches the naive reference's "{user_id}-{index_within_user}" style.
    df["_session_ordinal"] = new_session.groupby(df["user_id"]).cumsum() - 1
    df["session_id"] = (
        df["user_id"].astype(str) + "-" + df["_session_ordinal"].astype(str)
    )

    agg = df.groupby("session_id", sort=False).agg(
        user_id=("user_id", "first"),
        start_ts=("timestamp", "min"),
        end_ts=("timestamp", "max"),
        request_count=("timestamp", "size"),
        total_bytes=("bytes", "sum"),
    )
    agg["bounce"] = agg["request_count"] == 1
    agg = agg.reset_index()

    with open(output_path, "w") as f:
        for record in agg.to_dict(orient="records"):
            f.write(json.dumps(record, sort_keys=True))
            f.write("\n")
