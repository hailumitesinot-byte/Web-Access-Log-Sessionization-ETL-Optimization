# Optimize a Web-Access-Log Sessionization ETL Pipeline for Scale

## Objective

The repo at `/app` contains a log-analytics ETL pipeline (`etl/sessionize.py`)
that turns raw web-server access logs into per-user session records. The
pipeline is functionally correct but was written for prototyping against a
few thousand rows: it iterates the input with pandas `.iterrows()`, rebuilds
Python lists via repeated `.append()` calls, and re-scans already-seen rows
with a linear search to decide whether a new log line continues an existing
session. This makes it effectively quadratic in the number of log lines.

You must rewrite the sessionization + aggregation stage (`etl/sessionize.py`
and any code it calls) so that it:

1. Produces output that is byte-identical (after canonical JSON
   normalization) to the existing reference behavior: group log lines by
   `user_id`, sort by `timestamp`, and split into sessions wherever the gap
   between two consecutive requests from the same user exceeds 30 minutes.
   Each session record reports `session_id`, `user_id`, `start_ts`, `end_ts`,
   `request_count`, `total_bytes`, and a `bounce` flag (`request_count == 1`).
2. Handles logs that are only approximately sorted by time (not guaranteed
   globally ordered), contains duplicate log lines (same `user_id` +
   `timestamp` + `request_id`, which must be deduplicated before
   sessionization), and does not change the on-disk output schema or the CLI
   entrypoint that `tests/test.sh` invokes.
3. Processes a 6,000,000-line access-log file within a fixed wall-clock
   budget on the sandbox hardware.

## Constraints

You may **not**:
- Change the session-boundary rule (30-minute gap).
- Drop the dedup step.
- Alter the public CLI contract that `tests/test_public.py` exercises
  locally (`python -m etl <input> <output>`).

## Environment

- Base image: `python:3.11-slim` with `pandas`, `numpy`, and `pyarrow`
  preinstalled.
- `/app` contains:
  - `etl/sessionize.py` — the naive reference pipeline to optimize
  - `etl/__main__.py` — CLI entrypoint (`python -m etl <input> <output>`)
  - `data/sample_logs.jsonl` — a 50,000-line local dev sample (JSON lines:
    `timestamp`, `user_id`, `request_id`, `url`, `status_code`, `bytes`)
  - `tests/test_public.py` — a small correctness check you can run locally
- No network access at runtime; all dependencies are baked into the image.
- The full 6,000,000-line benchmark file used for grading is **not** present
  in your sandbox and is supplied only to the sealed verifier.

## Hints

The obvious first instinct — wrap the existing per-row loop in
multiprocessing or a thread pool — does not work correctly here. Session
boundaries depend on strictly ordered per-user processing, so chunking the
file arbitrarily across workers silently splits or merges sessions at chunk
boundaries. The verifier checks an exact output hash, not aggregate counts,
so a subtly-wrong-but-fast solution will fail.

The real fix: replace row-wise iteration and repeated linear scans with a
vectorized group-by/sort/shift-based approach (or an equivalent single-pass
algorithm dominated by an O(n log n) sort), while still correctly handling
approximately-ordered input, duplicate log lines, and ties at exactly the
30-minute boundary.
