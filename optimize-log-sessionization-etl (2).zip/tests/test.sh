#!/usr/bin/env bash
# Sealed verifier entrypoint.
#
# At grading time this script runs in an environment where the following
# are additionally present (populated by the grading harness, NOT part of
# the agent-visible bundle):
#   tests/sealed/holdout_6m.jsonl        - the 6,000,000-line benchmark file
#   tests/sealed/reference_hash.txt      - canonical-hash of the reference
#                                            output on holdout_6m.jsonl
#   tests/sealed/reference_hash_public.txt - canonical-hash on the public
#                                            sample, for the same check
#   tests/sealed/thresholds.env          - CEILING_SECONDS / TARGET_SECONDS
#
# The agent's sandbox never contains tests/sealed/. This script is
# included so the bundle's layout and grading logic are inspectable and
# testable end-to-end once sealed fixtures are attached by the harness.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SEALED_DIR="${REPO_ROOT}/tests/sealed"
WORK_DIR="$(mktemp -d)"
trap 'rm -rf "${WORK_DIR}"' EXIT

CEILING_SECONDS=90
TARGET_SECONDS=60
if [[ -f "${SEALED_DIR}/thresholds.env" ]]; then
  # shellcheck disable=SC1090
  source "${SEALED_DIR}/thresholds.env"
fi

canonicalize_and_hash() {
  # Stable key ordering + normalized number formatting, then sha256.
  python3 - "$1" <<'PY' | tail -n1
import json
import sys

path = sys.argv[1]
lines = []
with open(path) as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        obj = json.loads(line)
        norm = {k: obj[k] for k in sorted(obj.keys())}
        lines.append(json.dumps(norm, sort_keys=True, separators=(",", ":")))
lines.sort()
import hashlib
h = hashlib.sha256("\n".join(lines).encode("utf-8")).hexdigest()
print(h)
PY
}

fail() {
  echo "FAIL: $1" >&2
  exit 1
}

# --- Stage 1: correctness on the public sample -----------------------------
PUBLIC_OUT="${WORK_DIR}/public_out.jsonl"
python3 -m etl "${REPO_ROOT}/data/sample_logs.jsonl" "${PUBLIC_OUT}"
public_hash="$(canonicalize_and_hash "${PUBLIC_OUT}")"

if [[ -f "${SEALED_DIR}/reference_hash_public.txt" ]]; then
  expected_public_hash="$(cat "${SEALED_DIR}/reference_hash_public.txt")"
  [[ "${public_hash}" == "${expected_public_hash}" ]] \
    || fail "public sample output hash mismatch"
else
  echo "warning: sealed public reference hash not present; skipping check" >&2
fi

# --- Stage 2: correctness + performance on the held-out 6M-line file -------
if [[ -f "${SEALED_DIR}/holdout_6m.jsonl" ]]; then
  HOLDOUT_OUT="${WORK_DIR}/holdout_out.jsonl"

  start_ts=$(date +%s.%N)
  python3 -m etl "${SEALED_DIR}/holdout_6m.jsonl" "${HOLDOUT_OUT}"
  end_ts=$(date +%s.%N)
  elapsed=$(python3 -c "print(${end_ts} - ${start_ts})")

  holdout_hash="$(canonicalize_and_hash "${HOLDOUT_OUT}")"
  expected_holdout_hash="$(cat "${SEALED_DIR}/reference_hash.txt")"
  [[ "${holdout_hash}" == "${expected_holdout_hash}" ]] \
    || fail "held-out output hash mismatch"

  passed=$(python3 -c "print(1 if ${elapsed} <= ${CEILING_SECONDS} else 0)")
  [[ "${passed}" == "1" ]] || fail "elapsed ${elapsed}s exceeded ceiling ${CEILING_SECONDS}s"

  # Continuous reward: 0 at ceiling, 1.0 at/below target, linear between.
  score=$(python3 -c "
elapsed = ${elapsed}
ceiling = ${CEILING_SECONDS}
target = ${TARGET_SECONDS}
if elapsed <= target:
    score = 1.0
elif elapsed >= ceiling:
    score = 0.0
else:
    score = (ceiling - elapsed) / (ceiling - target)
print(f'{score:.4f}')
")
  echo "elapsed_seconds=${elapsed}"
  echo "score=${score}"
else
  echo "warning: sealed held-out benchmark not present; skipping stage 2" >&2
fi

echo "PASS"
