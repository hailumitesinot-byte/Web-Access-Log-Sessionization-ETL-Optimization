"""
Local self-check for the agent. This does NOT contain the sealed
reference hash or the 6,000,000-line benchmark file -- it only checks
schema, basic invariants, and the CLI contract against the public
50k-line sample. The real grading (exact-hash correctness + timing on
the held-out file) happens in tests/test.sh against sealed data that is
not present in the agent's sandbox.
"""

import json
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SAMPLE = REPO_ROOT / "data" / "sample_logs.jsonl"
REQUIRED_FIELDS = {
    "session_id",
    "user_id",
    "start_ts",
    "end_ts",
    "request_count",
    "total_bytes",
    "bounce",
}
GAP_SECONDS = 30 * 60


def run_pipeline(input_path: Path, output_path: Path) -> None:
    result = subprocess.run(
        [sys.executable, "-m", "etl", str(input_path), str(output_path)],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, f"pipeline failed:\n{result.stderr}"


def load_sessions(path: Path) -> list[dict]:
    sessions = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                sessions.append(json.loads(line))
    return sessions


def test_cli_contract_and_schema(tmp_path):
    out_path = tmp_path / "out.jsonl"
    run_pipeline(SAMPLE, out_path)
    sessions = load_sessions(out_path)
    assert len(sessions) > 0
    for s in sessions:
        assert REQUIRED_FIELDS <= s.keys()
        assert s["bounce"] == (s["request_count"] == 1)
        assert s["end_ts"] >= s["start_ts"]
        assert s["request_count"] >= 1
        assert s["total_bytes"] >= 0


def test_session_gap_invariant(tmp_path):
    # A same-user session's duration should never span more than the
    # sum of internal gaps that are each <= 30 minutes -- i.e. no two
    # sessions for the same user should be mergeable (their boundary
    # gap must exceed 30 minutes).
    out_path = tmp_path / "out.jsonl"
    run_pipeline(SAMPLE, out_path)
    sessions = load_sessions(out_path)

    by_user: dict[str, list[dict]] = {}
    for s in sessions:
        by_user.setdefault(s["user_id"], []).append(s)

    for user_sessions in by_user.values():
        user_sessions.sort(key=lambda s: s["start_ts"])
        for a, b in zip(user_sessions, user_sessions[1:]):
            assert b["start_ts"] - a["end_ts"] > GAP_SECONDS


def test_idempotent_on_public_sample(tmp_path):
    # Running twice on the same input should produce identical output.
    out1 = tmp_path / "out1.jsonl"
    out2 = tmp_path / "out2.jsonl"
    run_pipeline(SAMPLE, out1)
    run_pipeline(SAMPLE, out2)
    assert out1.read_text() == out2.read_text()
